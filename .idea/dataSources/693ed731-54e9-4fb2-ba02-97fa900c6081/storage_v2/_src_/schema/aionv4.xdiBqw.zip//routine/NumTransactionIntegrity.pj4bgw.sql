create procedure NumTransactionIntegrity(IN startBlock bigint(64))
BEGIN
DECLARE i INT;
DECLARE numTransactionsInBlock BIGINT(64);
DECLARE numTransactionsInTransaction BIGINT(64);
SELECT block_number INTO i FROM parser_state WHERE ID=1;
CREATE TEMPORARY TABLE TX_TEMP(block_number bigint(64));
WHILE i>startBlock DO
  SELECT num_transactions INTO numTransactionsInBlock FROM block WHERE block_number=i;
  SELECT count(*) INTO numTransactionsInTransaction FROM transaction WHERE block_number=i;
  IF numTransactionsInBlock != numTransactionsInTransaction
  THEN INSERT INTO TX_TEMP VALUES(i);
  END IF;
  SET i = i - 1;
END WHILE;
SELECT * FROM TX_TEMP;
DROP TABLE TX_TEMP;
END;

